import { Link, useLocation } from "react-router-dom";
import { LayoutDashboard, Radio, Calendar, Lightbulb, History, DollarSign, Shield, LogOut } from "lucide-react";
import { supabase } from "@/lib/supabase";;
import { useUserRole } from "@/hooks/useUserRole";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/" },
  { icon: Radio, label: "En Vivo", path: "/live" },
  { icon: Calendar, label: "Programados", path: "/scheduled" },
  { icon: Lightbulb, label: "Consejos", path: "/tips" },
  { icon: History, label: "Mis Picks", path: "/history" },
  { icon: DollarSign, label: "Bankroll", path: "/bankroll" },
];

export default function Sidebar() {
  const location = useLocation();
  const { isAdmin } = useUserRole();

  return (
    <div className="fixed left-0 top-0 h-full w-64 bg-sidebar border-r border-sidebar-border flex flex-col z-40">
      {/* Logo */}
      <div className="p-6 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center">
            <span className="text-primary-foreground font-space font-black text-sm">BA</span>
          </div>
          <div>
            <p className="font-space font-black text-sidebar-foreground text-sm leading-tight">BetAnalyzer</p>
            <p className="text-[10px] text-muted-foreground">Pro Analytics</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navItems.map(({ icon: Icon, label, path }) => {
          const isActive = location.pathname === path;
          return (
            <Link
              key={path}
              to={path}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all text-sm font-medium ${
                isActive
                  ? "bg-sidebar-primary/10 text-sidebar-primary border border-sidebar-primary/20"
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              {label}
            </Link>
          );
        })}

        {isAdmin && (
          <Link
            to="/admin"
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all text-sm font-medium mt-4 ${
              location.pathname === "/admin"
                ? "bg-destructive/10 text-destructive border border-destructive/20"
                : "text-destructive/70 hover:bg-destructive/10 hover:text-destructive"
            }`}
          >
            <Shield className="w-4 h-4 shrink-0" />
            Admin
          </Link>
        )}
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-sidebar-border">
        <button
          onClick={() => supabase.auth.signOut()}}
          className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-all w-full"
        >
          <LogOut className="w-4 h-4" />
          Cerrar sesión
        </button>
      </div>
    </div>
  );
}

matches
